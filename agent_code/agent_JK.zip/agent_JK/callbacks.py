#import os
#import pickle
import numpy as np
import json
import settings as s
np.set_printoptions(precision=2)
np.set_printoptions(suppress=True)
#from os import chdir, getcwd

ACTIONS = ['UP', 'RIGHT', 'DOWN', 'LEFT', 'WAIT', 'BOMB']

def setup(self):
    """
    Setup your code. This is called once when loading each agent.
    Make sure that you prepare everything such that act(...) can be called.

    When in training mode, the separate `setup_training` in train.py is called
    after this method. This separation allows you to share your trained agent
    with other students, without revealing your training code.

    In this example, our model is a set of probabilities over actions
    that are is independent of the game state.

    :param self: This object is passed to all callbacks and you can set arbitrary values.
    """
    
    self.round = 0
    self.step = 0
    
    if self.train:
        print('start training')
    else:
        print('start in playing mode') 
        with open("./inputfiles/QaTable.json", "r") as read_file:
            self.QaTable = json.load(read_file)
        self.loaded = True
        print('QaTable.json loaded successfully.')
        self.states_encountered_aslist = list(self.QaTable.keys())
        self.Qa_encountered = list(self.QaTable.values())
        self.states_encountered = np.asarray([np.array(np.matrix(x)).ravel() for x in self.states_encountered_aslist])
    
def act(self, game_state: dict) -> str:
    """
    Your agent should parse the input, think, and take a decision.
    When not in training mode, the maximum execution time for this method is 0.5s.

    :param self: The same object that is passed to all of your callbacks.
    :param game_state: The dictionary that describes everything on the board.
    :return: The action to take as a string.
    """
    
    self.step += 1
    
    if self.train:
        s = state_to_features(game_state)
        if str(s) in self.QaTable:
            if not str(s) in self.s_freq: print('step %i: sth wrong' %self.step)
            Qa = self.QaTable[str(s)]
        else:
             Qa = Qini(s)
        #print('Qa: ', Qa)
        Qa += 0.03*np.random.randint(-9, 10, size=6) # avoid loops
        #a = np.argmax(Qa)
        '''
        rho = 0.9**self.round
        if rho > 0.1:
            a = np.random.choice(6, p=softmax(np.array(Qa), rho))
            #print('softmax(Qa, rho): ', softmax(Qa, rho))
        else:
            a = np.argmax(Qa)
        '''
        a = np.argmax(Qa)
        return ACTIONS[a]
    
    else:
        s = state_to_features(game_state)
        s_sim, Qa = get_most_similar_state(self, s)
        Qa += 0.03*np.random.randint(-9, 10, size=6) # avoid loops
        a = np.argmax(Qa)
        return ACTIONS[a]
    
def state_to_features(game_state: dict) -> np.array:
    """
    *This is not a required function, but an idea to structure your code.*

    Converts the game state to the input of your model, i.e.
    a feature vector.

    You can find out about the state of the game environment via game_state,
    which is a dictionary. Consult 'get_state_for_agent' in environment.py to see
    what it contains.

    :param game_state:  A dictionary describing the current game board.
    :return: np.array [local env, closest coin, closest bomb, closest enemy, canbomb]
    """
    
    # This is the dict before the game begins and after it ends
    if game_state is None:
        return None
    
    # 1 environment
    env = game_state['field'] # -1 stone walls, 0 free tiles, 1 crates
    sx, sy = game_state['self'][3]
    
    # 2 coins
    for cx, cy in game_state['coins']: #[(x, y)]
        env[cx, cy] = 2
        
    # 3 opponents => like crates (drop a bomb if next to)
    if len(game_state['others']):
        for opn,ops,opb,(opx,opy) in game_state['others']: # (n; s; b; (x; y)) of opponents
            env[opx, opy] = 1  
    
    # 4 bombs    
    for (bombx, bomby), bombtime in game_state['bombs']:  #[(x, y), t]
        env[bombx, bomby] = -6
        
    #print('Large env: \n', env.T)
    
    # 5 density of free tiles in each direction
    dens = np.zeros(4) # up, right, down, left
    # UP
    if env[sx,sy-1] in (0,2):
        for y in np.arange(sy-2,sy):
            if y in np.arange(env.shape[1]):
                for x in np.arange(sx-1,sx+2):
                    if env[x,y] in (0,2):
                        dens[0] += 1
    # DOWN
    if env[sx,sy+1] in (0,2):
        for y in np.arange(sy+1,sy+3):
            if y in np.arange(env.shape[1]):
                for x in np.arange(sx-1,sx+2):
                    if env[x,y] in (0,2):
                        dens[2] += 1
    # RIGHT
    if env[sx+1,sy] in (0,2):
        for x in np.arange(sx+1,sx+3):
            if x in np.arange(env.shape[0]):
                for y in np.arange(sy-1,sy+2):
                    if env[x,y] in (0,2):
                        dens[1] += 1
    # LEFT
    if env[sx-1,sy] in (0,2):
        for x in np.arange(sx-2,sx):
            if x in np.arange(env.shape[0]):
                for y in np.arange(sy-1,sy+2):
                    if env[x,y] in (0,2):
                        dens[3] += 1
    #print('\ndens: ', dens)
    free_direction = np.argmax(dens)
      
    # 6 explosion map        
    # more negative if bomb explodes soon
    for (bombx, bomby), bombtime in game_state['bombs']:  #[(x, y), t]
        for dx in range(4):
            if bombx+dx in range(env.shape[0]):
                if env[bombx+dx, bomby] == -1: 
                    break
                elif env[bombx+dx, bomby] == 2 and bombtime == 0:
                    #print('bombtime: ', bombtime)
                    env[bombx+dx, bomby] = bombtime-5
                elif env[bombx+dx, bomby] == 0: 
                    env[bombx+dx, bomby] = bombtime-5
        for dx in np.arange(-1,-4, -1):
            if bombx+dx in range(env.shape[0]):
                if env[bombx+dx, bomby] == -1: 
                    break
                elif env[bombx+dx, bomby] == 2 and bombtime == 0: 
                    #print('bombtime: ', bombtime)
                    env[bombx+dx, bomby] = bombtime-5
                elif env[bombx+dx, bomby] == 0: 
                    env[bombx+dx, bomby] = bombtime-5
        for dy in range(4):
            if bomby+dy in range(env.shape[1]):
                if env[bombx, bomby+dy] == -1: 
                    break
                elif env[bombx, bomby+dy] == 2 and bombtime == 0: 
                    #print('bombtime: ', bombtime)
                    env[bombx, bomby+dy] = bombtime-5
                elif env[bombx, bomby+dy] == 0: 
                    env[bombx, bomby+dy] = bombtime-5
        for dy in np.arange(-1,-4, -1):
            if bomby+dy in range(env.shape[1]):
                if env[bombx, bomby+dy] == -1: 
                    break
                elif env[bombx, bomby+dy] == 2 and bombtime == 0: 
                    #print('bombtime: ', bombtime)
                    env[bombx, bomby+dy] = bombtime-5
                elif env[bombx, bomby+dy] == 0: 
                    env[bombx, bomby+dy] = bombtime-5
    #print('Game field: \n', env.T)
    
    # 7 closest target (bombs > coins > crates > opponents)
    if len(game_state['coins']):
        coins = []
        for cx, cy in game_state['coins']:
            cdx = cx-sx
            cdy = cy-sy
            coins.append([cdx, cdy])
        coins = np.asarray(coins)
        dist = np.array([np.abs(coins[:,0])+np.abs(coins[:,1])]).T
        coins = np.append(coins, dist, axis=1)
        np.random.shuffle(coins) # shuffle rows to randomize btw equally distant targets
        coins = coins[np.argmin(coins[:,2]),:2]
        cltarget = np.sign(coins[0]), np.sign(coins[1])
    else:
        cltarget = [0,0]
        crates = []
        # find closest crate or opponent
        for x in range(env.shape[0]):
            for y in range(env.shape[0]):
                if env[x,y] == 1:
                    #print('found a crate')
                    crdx = x-sx
                    crdy = y-sy
                    crates.append([crdx, crdy])
        if crates:
            crates = np.asarray(crates)
            dist = np.array([np.abs(crates[:,0])+np.abs(crates[:,1])]).T
            crates = np.append(crates, dist, axis=1)
            np.random.shuffle(crates) # shuffle rows to randomize btw equally distant targets
            crates = crates[np.argmin(crates[:,2]),:2]
            cltarget = np.sign(crates[0]), np.sign(crates[1])
        else:
            cltarget = np.array([0, 0])
    #print('closest target: ', cltarget)
      
    # 8 self: bomb available
    canbomb = game_state['self'][2]
    
    # crop
    env = env[sx-1:sx+2, sy-1:sy+2]
    
    # combine
    env = env.reshape(-1)
    #state = np.hstack((clcoin))
    state = np.hstack((env,cltarget,free_direction,canbomb))
    #print('state \n', state)
    
    '''
    print('env: ', env.T)
    print('clcoin: ', clcoin)
    print('clbomb: ', clbomb)
    print('clop: ', clop)
    print('canbomb: ', canbomb)
    env = env.reshape(-1)
    state = np.hstack((env,clcoin,clbomb,clop,canbomb))
    print('state: ', state)
    '''
    
    return state



''' Functions '''
def get_most_similar_state(self,s):
    # training 2d array: self.states_encountered
    # test 1d array: s
    dist_vec = np.linalg.norm(self.states_encountered[:, None, :] - s[None, None, :], axis=-1)
    best = np.argmin(dist_vec)
    return self.states_encountered[best], self.Qa_encountered[best]
    
  